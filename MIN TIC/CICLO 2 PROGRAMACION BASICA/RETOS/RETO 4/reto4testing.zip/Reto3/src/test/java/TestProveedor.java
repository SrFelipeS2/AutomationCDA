/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import Clases.Proveedores;
import Model.ModeloProveedores;
import java.sql.SQLException;
import static junit.framework.TestCase.assertEquals;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ANDRES
 */
public class TestProveedor {
    
    public TestProveedor() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

  
    @Test 
    public void actualizarVoid(){
        Proveedores proveedor = new Proveedores();
        ModeloProveedores modelo = new ModeloProveedores();
        int result = modelo.actualizar(proveedor);
        
        assertEquals(1, result);
    }
    
    @Test 
    public void actualizar(){
        Proveedores proveedor = new Proveedores();
        
        proveedor.setNit("852");
        proveedor.setRazonSocial("junittest");
        proveedor.setBarrio("junit");
        proveedor.setCalle_Carrera("calle 45 numero 45");
        proveedor.setCiudad("junit");
        proveedor.setCorreoElectronico("junit@mail.com");
        proveedor.setNumero("0000222");
        proveedor.setRepresentante("testin testing");
        proveedor.setSitioWeb("testing.com");
        proveedor.setTelefono("22222233333");
        
        ModeloProveedores modelo = new ModeloProveedores();
        
        int result = modelo.actualizar(proveedor);
        
        assertEquals(3, result);
    }
    
    @Test 
    public void actualizarError(){
        Proveedores proveedor = new Proveedores();
        ModeloProveedores modelo = new ModeloProveedores();
        int result = modelo.actualizar(proveedor);
        
        assertEquals(2, result);
    }
    
    @Test 
    public void eliminar(){
       
        ModeloProveedores modelo = new ModeloProveedores();
        
        int result = 0;
        try{
            result = modelo.eliminar("852");
        }catch(SQLException e){
            
        }        
        assertEquals(2, result);
    }
    
    
    @Test
    public void eliminarNotFound(){
       
        ModeloProveedores modelo = new ModeloProveedores();
        
        int result = 0;
        try{
            result = modelo.eliminar("852");
        }catch(SQLException e){
            
        }        
        assertEquals(1, result);
    }
    
    @Test(expected = SQLException.class)
    public void eliminarSQL() throws SQLException{
        
        ModeloProveedores modelo = new ModeloProveedores();
       
          
        assertEquals(SQLException.class, modelo.eliminar("123456"));
    }
}
